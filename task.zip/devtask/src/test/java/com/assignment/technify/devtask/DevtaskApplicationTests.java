package com.assignment.technify.devtask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevtaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
