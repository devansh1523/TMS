package com.assignment.technify.devtask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevtaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevtaskApplication.class, args);
	}

}
